//// FriendListInventory.java
//package de.menu.friendsysten;
//
//import org.bukkit.entity.Player;
//import org.bukkit.inventory.Inventory;
//import org.bukkit.plugin.java.JavaPlugin;
//
//public class FriendListInventory {
//
//    private final JavaPlugin plugin;
//
//    public FriendListInventory(JavaPlugin plugin) {
//        this.plugin = plugin;
//    }
//
//    public Inventory createFriendListInventory(Player player) {
//        // Implementiere die Methode, um das Inventar mit der Freundesliste zu erstellen
//        return null;
//    }
//}
