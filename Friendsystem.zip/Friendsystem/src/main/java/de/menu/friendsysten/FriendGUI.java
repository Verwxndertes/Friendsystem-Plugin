//// FriendGUI.java
//package de.menu.friendsysten;
//
//import org.bukkit.entity.Player;
//import org.bukkit.inventory.Inventory;
//import org.bukkit.plugin.java.JavaPlugin;
//
//public class FriendGUI {
//
//    private final JavaPlugin plugin;
//
//    public FriendGUI(JavaPlugin plugin) {
//        this.plugin = plugin;
//    }
//
//    public void showUsage(Player player) {
//        // Implementiere die Methode, um die korrekte Verwendung der Befehle anzuzeigen
//    }
//
//    public void openFriendListInventory(Player player) {
//        // Implementiere die Methode, um das Inventar mit der Freundesliste zu öffnen
//    }
//}
