//// FriendManager.java
//package de.menu.friendsysten;
//
//import org.bukkit.entity.Player;
//import org.bukkit.plugin.java.JavaPlugin;
//
//public class FriendManager {
//
//    private final JavaPlugin plugin;
//
//    public FriendManager(JavaPlugin plugin) {
//        this.plugin = plugin;
//    }
//
//    public void addFriend(Player sender, String targetName) {
//        // Implementiere die Methode, um einen Freund hinzuzufügen
//    }
//
//    public void acceptFriendRequest(Player receiver, String senderName) {
//        // Implementiere die Methode, um eine Freundesanfrage zu akzeptieren
//    }
//
//    public void denyFriendRequest(Player receiver, String senderName) {
//        // Implementiere die Methode, um eine Freundesanfrage abzulehnen
//    }
//
//    public void removeFriend(Player sender, String targetName) {
//        // Implementiere die Methode, um einen Freund zu entfernen
//    }
//
//    public void loadFriendData(Player player) {
//        // Implementiere die Methode, um die Freundesliste eines Spielers zu laden
//    }
//
//    public void notifyOnlineFriends(Player player) {
//        // Implementiere die Methode, um online Freunde zu benachrichtigen, wenn ein Spieler dem Server beitritt
//    }
//}
